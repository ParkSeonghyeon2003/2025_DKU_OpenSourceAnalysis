extern long last_value_latestgen;
extern long count_basis_latestgen;

void init_latestgen(long init_val);
long next_value_latestgen();
